# Viral Ranking Research Engine

AI-powered research assistant for discovering viral funny moments and ranking
video opportunities from YouTube and TikTok.

**This is a research assistant only.** It never downloads videos, never
bypasses copyright/platform protections, and only analyzes publicly available
metadata.

## Stack

- **Backend:** Python, FastAPI, SQLAlchemy, SQLite, httpx, Pydantic
- **Frontend:** React + TypeScript + Vite
- **AI:** Single `generate()` router with failover across GitHub Models → OpenRouter → custom `AGENT_URL`

No Redis, no Celery, no Kubernetes, no Docker (unless later required) — kept
intentionally lightweight per project rules.

## Focus content categories

Funny Failed Moments · Epic Fails · Instant Karma · Lucky Escapes ·
Sports Fails · Animal Fails · Unexpected Moments · Public Funny Videos

## Project structure

```
backend/
  app/
    core/       -> config.py (env var loading, never hardcode secrets)
    db/         -> SQLAlchemy engine/session + declarative base
    models/     -> Video, Research, Moment, Idea, SearchHistory
    schemas/    -> Pydantic request/response models + agent output contracts
    api/        -> FastAPI routers: search, videos, moments, ideas, agents
    services/   -> youtube_service.py, tiktok_service.py (external sources)
    agents/     -> 5 agents (viral opportunity, hook detection, story flow,
                   seo viral, competitor research)
    ai/         -> router.py, the single generate() LLM entrypoint
    main.py     -> FastAPI app instance, router wiring, table creation
  requirements.txt
  .env.example
frontend/
  src/
    pages/      -> Dashboard, Search, Results, MomentSuggestions, Trending, SavedIdeas
    components/
    services/   -> api.ts (fetch wrapper against backend)
    hooks/
```

## Build phases

- **Phase 1 ✅:** folder structure, backend architecture, DB models, API design/contracts.
- **Phase 2 ✅:** YouTube Data API integration, TikTok public web-search + LLM discovery module, AI router failover (GitHub Models → OpenRouter → AGENT_URL).
- **Phase 3 ✅:** All 5 agents implemented (Viral Opportunity, Hook Detection, Story Flow, SEO Viral, Competitor Research), wired to real endpoints and DB data. 36 automated tests total — run with `pytest` from `backend/`.
- **Phase 4:** Build out the React frontend pages and connect them to the API.

### Phase 3 notes & decisions

- **`Video.viral_score` / `Video.engagement_ratio`** (overall, per-video) added alongside the existing **`Moment.viral_score`** (per-clip) — both levels are scored, per review decision.
- **No Dandelion/sentiment API.** Any text analysis needed by an agent goes through the existing `generate()` router instead of a dedicated sentiment API — avoids a new dependency + API key for something the LLM router already covers.
- **pytrends (Google Trends) and Urban Dictionary API are deferred** to a later phase — not part of Phase 3. The 5 core agents were prioritized first.
- **`generate(json_mode=True)`**: GitHub Models and OpenRouter (both OpenAI-compatible) now get `response_format={"type": "json_object"}` to constrain output to valid JSON. `extract_json()` is still used as a safety net since AGENT_URL's contract is custom and not every model obeys `response_format` perfectly.
- **Story Flow Agent** guards against the LLM hallucinating or dropping moment ids — hallucinated ids are filtered out, dropped ids are appended in original order, so no moment is ever silently lost.
- **Competitor Research Agent** reads already-persisted `Video` rows for a channel (from prior `/search/` calls) rather than fetching live — run `/search/` for a channel first if `/agents/competitor-research` 404s.
- Run tests: `cd backend && pip install -r requirements.txt -r requirements-dev.txt && pytest`

## Environment variables

Copy `backend/.env.example` to `backend/.env` and fill in:

```
YOUTUBE_API_KEY=
GITHUB_MODELS_TOKEN=
OPENROUTER_API_KEY=
MODEL_REASONING=
MODEL_WRITER=
OPENROUTER_MODEL=
STORY_MODEL_PREFERENCE=
AGENT_URL=
```

## Running (once Phase 2+ lands)

```bash
# backend
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload

# frontend
cd frontend
npm install
npm run dev
```

## License

MIT — see `LICENSE`.
