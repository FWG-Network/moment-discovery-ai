from datetime import datetime

from pydantic import BaseModel, ConfigDict


class SearchFilters(BaseModel):
    """Shared filter shape used across search endpoints."""

    platform: str | None = None  # "youtube" | "tiktok" | None (both)
    keyword: str | None = None
    topic: str | None = None
    date_from: datetime | None = None
    date_to: datetime | None = None
    language: str | None = None
    region: str | None = None
    min_views: int | None = None
    max_duration: int | None = None


class ResearchCreate(BaseModel):
    query: str
    filters: SearchFilters | None = None


class ResearchOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    query: str
    filters: str | None = None
    results_count: int
    created_at: datetime
