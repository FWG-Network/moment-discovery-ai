from datetime import datetime

from pydantic import BaseModel, ConfigDict


class VideoBase(BaseModel):
    platform: str
    title: str
    channel: str | None = None
    url: str
    publish_date: datetime | None = None
    views: int | None = None
    duration: int | None = None
    thumbnail: str | None = None
    tags: str | None = None


class VideoCreate(VideoBase):
    pass


class VideoOut(VideoBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    viral_score: float | None = None
    engagement_ratio: float | None = None
    created_at: datetime
