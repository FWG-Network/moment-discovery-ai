from pydantic import BaseModel


class TikTokDiscoveryItem(BaseModel):
    """One publicly discoverable TikTok post, as extracted by the browsing agent."""

    title: str
    url: str  # kept as str (not HttpUrl) so a malformed single item doesn't crash the whole batch
    creator: str | None = None
    thumbnail: str | None = None
    search_source: str | None = None
