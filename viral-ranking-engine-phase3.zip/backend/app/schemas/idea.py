from datetime import datetime

from pydantic import BaseModel, ConfigDict


class IdeaBase(BaseModel):
    moment_id: int
    rank_position: int | None = None
    hook_score: float | None = None
    curiosity_score: float | None = None


class IdeaCreate(IdeaBase):
    pass


class IdeaOut(IdeaBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    created_at: datetime
