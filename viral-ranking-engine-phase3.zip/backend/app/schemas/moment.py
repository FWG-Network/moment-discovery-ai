from datetime import datetime

from pydantic import BaseModel, ConfigDict


class MomentBase(BaseModel):
    video_id: int
    timestamp: int | None = None
    description: str | None = None
    viral_score: float | None = None


class MomentCreate(MomentBase):
    pass


class MomentOut(MomentBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    created_at: datetime
