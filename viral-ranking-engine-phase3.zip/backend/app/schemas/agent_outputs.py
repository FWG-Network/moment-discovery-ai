"""
Structured JSON contracts returned by each agent.

Per AI_Rules: responses must be short, structured JSON, no long explanations.
Only the single `generate()` router function is used to talk to an LLM;
these schemas define what we ask it to return.
"""
from pydantic import BaseModel


class ViralOpportunityResult(BaseModel):
    viral_score: float
    engagement_ratio: float  # rough views-vs-norm heuristic (no subscriber data available)
    hook_score: float
    curiosity_score: float
    replay_potential: float
    freshness: float
    overall_recommendation: str


class HookDetectionResult(BaseModel):
    scroll_stop_score: float
    hook_strength: float
    curiosity_level: float


class StoryFlowResult(BaseModel):
    """Ordering recommendation only, e.g. moment ids from #10 down to #1."""
    ranked_moment_ids: list[int]


class SeoViralResult(BaseModel):
    viral_titles: list[str]
    seo_keywords: list[str]
    trending_keywords: list[str]
    hashtags: list[str]
    related_search_queries: list[str]


class CompetitorInsight(BaseModel):
    popular_topics: list[str]
    upload_frequency: str
    title_patterns: list[str]
    thumbnail_patterns: list[str]
    opportunities: list[str]
