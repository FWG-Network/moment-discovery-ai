from datetime import datetime

from fastapi import APIRouter, Depends
from fastapi.concurrency import run_in_threadpool
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.db.cache import get_cached_results, save_cached_results
from app.models.research import Research
from app.models.video import Video
from app.schemas.research import ResearchCreate, ResearchOut
from app.services.youtube_service import search_youtube, YouTubeAPIError
from app.services.tiktok_service import search_tiktok, TikTokDiscoveryError

router = APIRouter(prefix="/search", tags=["search"])

_VIDEO_FIELDS = {"platform", "title", "channel", "url", "publish_date", "views", "duration", "thumbnail", "tags"}


async def _search_platform(db: Session, query: str, platform: str) -> list[dict]:
    """Check cache first; otherwise call the live service and cache the result."""
    cached = await run_in_threadpool(get_cached_results, db, query, platform)
    if cached is not None:
        return cached

    if platform == "youtube":
        try:
            results = await search_youtube(query)
        except YouTubeAPIError:
            results = []  # degrade gracefully; don't fail the whole search over one platform
    elif platform == "tiktok":
        try:
            results = await search_tiktok(query)
        except TikTokDiscoveryError:
            results = []
    else:
        results = []

    await run_in_threadpool(save_cached_results, db, query, platform, results)
    return results


def _to_video_kwargs(result: dict) -> dict:
    """Coerce a raw service result dict into valid Video model kwargs."""
    kwargs = {k: v for k, v in result.items() if k in _VIDEO_FIELDS}
    publish_date = kwargs.get("publish_date")
    if isinstance(publish_date, str):
        try:
            kwargs["publish_date"] = datetime.fromisoformat(publish_date.replace("Z", "+00:00"))
        except ValueError:
            kwargs["publish_date"] = None
    return kwargs


@router.post("/", response_model=ResearchOut)
async def run_search(payload: ResearchCreate, db: Session = Depends(get_db)) -> ResearchOut:
    """
    Run a research query across YouTube + TikTok (or one platform if
    `filters.platform` is set), caching results and persisting new videos.
    """
    platform_filter = payload.filters.platform if payload.filters else None
    platforms = [platform_filter] if platform_filter else ["youtube", "tiktok"]

    all_results: list[dict] = []
    for platform in platforms:
        all_results.extend(await _search_platform(db, payload.query, platform))

    def _persist() -> Research:
        research = Research(
            query=payload.query,
            filters=payload.filters.model_dump_json() if payload.filters else None,
            results_count=len(all_results),
        )
        db.add(research)

        for result in all_results:
            url = result.get("url")
            if not url or db.query(Video).filter(Video.url == url).first():
                continue
            db.add(Video(**_to_video_kwargs(result)))

        db.commit()
        db.refresh(research)
        return research

    return await run_in_threadpool(_persist)
