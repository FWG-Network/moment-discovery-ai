from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.moment import Moment
from app.schemas.moment import MomentCreate, MomentOut

router = APIRouter(prefix="/moments", tags=["moments"])


@router.get("/", response_model=list[MomentOut])
def list_moments(video_id: int | None = None, db: Session = Depends(get_db)) -> list[Moment]:
    query = db.query(Moment)
    if video_id:
        query = query.filter(Moment.video_id == video_id)
    return query.order_by(Moment.viral_score.desc()).all()


@router.post("/", response_model=MomentOut)
def create_moment(payload: MomentCreate, db: Session = Depends(get_db)) -> Moment:
    moment = Moment(**payload.model_dump())
    db.add(moment)
    db.commit()
    db.refresh(moment)
    return moment


@router.get("/{moment_id}", response_model=MomentOut)
def get_moment(moment_id: int, db: Session = Depends(get_db)) -> Moment:
    moment = db.get(Moment, moment_id)
    if not moment:
        raise HTTPException(status_code=404, detail="Moment not found")
    return moment
