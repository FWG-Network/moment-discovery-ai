from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.video import Video
from app.schemas.video import VideoOut

router = APIRouter(prefix="/videos", tags=["videos"])


@router.get("/", response_model=list[VideoOut])
def list_videos(
    platform: str | None = None,
    limit: int = 50,
    db: Session = Depends(get_db),
) -> list[Video]:
    query = db.query(Video)
    if platform:
        query = query.filter(Video.platform == platform)
    return query.order_by(Video.created_at.desc()).limit(limit).all()


@router.get("/{video_id}", response_model=VideoOut)
def get_video(video_id: int, db: Session = Depends(get_db)) -> Video:
    video = db.get(Video, video_id)
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")
    return video
