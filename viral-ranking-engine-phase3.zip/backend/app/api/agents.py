from fastapi import APIRouter, Depends, HTTPException
from fastapi.concurrency import run_in_threadpool
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.video import Video
from app.models.moment import Moment
from app.schemas.agent_outputs import (
    ViralOpportunityResult,
    HookDetectionResult,
    StoryFlowResult,
    SeoViralResult,
    CompetitorInsight,
)
from app.agents.viral_opportunity_agent import score_video, ViralOpportunityAgentError
from app.agents.hook_detection_agent import detect_hook, HookDetectionAgentError
from app.agents.story_flow_agent import order_moments, StoryFlowAgentError
from app.agents.seo_viral_agent import generate_seo_package, SeoViralAgentError
from app.agents.competitor_research_agent import analyze_competitor, CompetitorResearchAgentError

router = APIRouter(prefix="/agents", tags=["agents"])


def _video_metadata(video: Video) -> dict:
    return {
        "title": video.title,
        "platform": video.platform,
        "channel": video.channel,
        "views": video.views,
        "duration": video.duration,
        "publish_date": video.publish_date.isoformat() if video.publish_date else None,
        "tags": video.tags,
    }


@router.post("/viral-opportunity", response_model=ViralOpportunityResult)
async def viral_opportunity_agent(video_id: int, db: Session = Depends(get_db)) -> ViralOpportunityResult:
    video = await run_in_threadpool(db.get, Video, video_id)
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")

    try:
        result = await score_video(_video_metadata(video))
    except ViralOpportunityAgentError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    def _persist() -> None:
        video.viral_score = result.viral_score
        video.engagement_ratio = result.engagement_ratio
        db.commit()

    await run_in_threadpool(_persist)
    return result


@router.post("/hook-detection", response_model=HookDetectionResult)
async def hook_detection_agent(video_id: int, db: Session = Depends(get_db)) -> HookDetectionResult:
    video = await run_in_threadpool(db.get, Video, video_id)
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")

    try:
        return await detect_hook(_video_metadata(video))
    except HookDetectionAgentError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.post("/story-flow", response_model=StoryFlowResult)
async def story_flow_agent(moment_ids: list[int], db: Session = Depends(get_db)) -> StoryFlowResult:
    def _load() -> list[Moment]:
        return db.query(Moment).filter(Moment.id.in_(moment_ids)).all()

    moments = await run_in_threadpool(_load)
    if not moments:
        raise HTTPException(status_code=404, detail="No matching moments found")

    moment_dicts = [{"id": m.id, "description": m.description} for m in moments]

    try:
        return await order_moments(moment_dicts)
    except StoryFlowAgentError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.post("/seo-viral", response_model=SeoViralResult)
async def seo_viral_agent(topic: str) -> SeoViralResult:
    try:
        return await generate_seo_package(topic)
    except SeoViralAgentError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.post("/competitor-research", response_model=CompetitorInsight)
async def competitor_research_agent(channel: str, db: Session = Depends(get_db)) -> CompetitorInsight:
    def _load() -> list[Video]:
        return (
            db.query(Video)
            .filter(Video.channel == channel)
            .order_by(Video.publish_date.desc())
            .limit(20)
            .all()
        )

    videos = await run_in_threadpool(_load)
    if not videos:
        raise HTTPException(
            status_code=404,
            detail=f"No videos found for channel '{channel}'. Run /search/ for this channel first.",
        )

    video_dicts = [
        {
            "title": v.title,
            "views": v.views,
            "publish_date": v.publish_date.isoformat() if v.publish_date else None,
        }
        for v in videos
    ]

    try:
        return await analyze_competitor(channel, video_dicts)
    except CompetitorResearchAgentError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
