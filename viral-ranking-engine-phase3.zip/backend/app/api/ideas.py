from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.idea import Idea
from app.schemas.idea import IdeaCreate, IdeaOut

router = APIRouter(prefix="/ideas", tags=["ideas"])


@router.get("/", response_model=list[IdeaOut])
def list_ideas(db: Session = Depends(get_db)) -> list[Idea]:
    return db.query(Idea).order_by(Idea.rank_position.asc()).all()


@router.post("/", response_model=IdeaOut)
def create_idea(payload: IdeaCreate, db: Session = Depends(get_db)) -> Idea:
    idea = Idea(**payload.model_dump())
    db.add(idea)
    db.commit()
    db.refresh(idea)
    return idea


@router.delete("/{idea_id}")
def delete_idea(idea_id: int, db: Session = Depends(get_db)) -> dict:
    idea = db.get(Idea, idea_id)
    if not idea:
        raise HTTPException(status_code=404, detail="Idea not found")
    db.delete(idea)
    db.commit()
    return {"deleted": True}
