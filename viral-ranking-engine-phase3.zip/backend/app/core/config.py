"""
Application configuration.
Reads all secrets/settings from environment variables (.env).
Never hardcode API keys.
"""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # --- API keys / provider tokens (all optional at import time) ---
    YOUTUBE_API_KEY: str | None = None
    GITHUB_MODELS_TOKEN: str | None = None
    OPENROUTER_API_KEY: str | None = None

    # --- Model routing preferences ---
    MODEL_REASONING: str | None = None
    MODEL_WRITER: str | None = None
    OPENROUTER_MODEL: str | None = None
    STORY_MODEL_PREFERENCE: str | None = None
    AGENT_URL: str | None = None

    # --- App-level settings ---
    APP_NAME: str = "Viral Ranking Research Engine"
    DATABASE_URL: str = "sqlite:///./viral_ranking.db"
    SEARCH_CACHE_TTL_DAYS: int = 7
    CORS_ORIGINS: list[str] = ["http://localhost:5173"]


@lru_cache
def get_settings() -> Settings:
    return Settings()
