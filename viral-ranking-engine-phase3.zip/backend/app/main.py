from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import get_settings
from app.db.base import Base
from app.db.session import engine
from app.api import search, videos, moments, ideas, agents

settings = get_settings()


@asynccontextmanager
async def lifespan(_app: FastAPI):
    # Import models so they're registered on Base.metadata, then create tables.
    from app.models import video, research, moment, idea, search_history  # noqa: F401

    Base.metadata.create_all(bind=engine)
    yield


app = FastAPI(title=settings.APP_NAME, lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(search.router)
app.include_router(videos.router)
app.include_router(moments.router)
app.include_router(ideas.router)
app.include_router(agents.router)


@app.get("/health")
def health() -> dict:
    return {"status": "ok", "app": settings.APP_NAME}
