"""
TikTok discovery via public web search + LLM extraction.

Per Project_Vision / Development_Rules: this module NEVER calls a TikTok API,
never scrapes or bypasses any access control, and never downloads video
files. It only asks a browsing-capable agent (AGENT_URL) to search the public
web (e.g. `site:tiktok.com <keyword>`-style queries) and extract publicly
visible metadata: title, URL, creator handle, thumbnail, and which query
surfaced it.

Plain chat-completion providers (GitHub Models, OpenRouter) cannot actually
browse the web, so this module deliberately uses
app.ai.router.generate_via_browsing_agent(), which is restricted to
AGENT_URL, instead of the general-purpose generate(). If AGENT_URL isn't
configured with a real search/browsing backend, this raises a clear error
rather than silently returning fabricated results.
"""
from pydantic import ValidationError

from app.ai.router import generate_via_browsing_agent, extract_json, AIProviderError
from app.schemas.tiktok import TikTokDiscoveryItem

_PROMPT_TEMPLATE = """\
Search the public web for TikTok posts matching: "{keyword}"

Use queries like: site:tiktok.com {keyword}

Return ONLY a JSON array (no prose, no markdown fences) of up to {max_results} \
objects, each with exactly these fields:
- title: string
- url: string (the public tiktok.com URL)
- creator: string or null (the @handle if visible)
- thumbnail: string or null
- search_source: string (the query that found it)

Only include posts you actually found via search. Do not invent results."""


class TikTokDiscoveryError(Exception):
    pass


async def search_tiktok(keyword: str, *, max_results: int = 25) -> list[dict]:
    """
    Discover public TikTok posts matching `keyword` and return normalized
    dicts ready to build app.models.video.Video rows.

    Raises TikTokDiscoveryError if no browsing-capable provider (AGENT_URL)
    is configured, or if the response can't be parsed as valid JSON.
    """
    prompt = _PROMPT_TEMPLATE.format(keyword=keyword, max_results=max_results)

    try:
        raw_text = await generate_via_browsing_agent(prompt)
    except AIProviderError as exc:
        raise TikTokDiscoveryError(str(exc)) from exc

    try:
        parsed = extract_json(raw_text)
    except ValueError as exc:
        raise TikTokDiscoveryError(f"Could not parse agent response as JSON: {exc}") from exc

    if not isinstance(parsed, list):
        raise TikTokDiscoveryError(f"Expected a JSON array, got: {type(parsed).__name__}")

    results = []
    for raw_item in parsed:
        try:
            item = TikTokDiscoveryItem.model_validate(raw_item)
        except ValidationError:
            continue  # skip malformed individual entries rather than failing the whole batch

        results.append({
            "platform": "tiktok",
            "title": item.title,
            "channel": item.creator,
            "url": item.url,
            "publish_date": None,  # not reliably available via search snippets
            "views": None,         # not reliably available via search snippets
            "duration": None,
            "thumbnail": item.thumbnail,
            "tags": item.search_source,
        })
    return results
