"""
YouTube Data API v3 integration.

Two-call pattern (per architecture notes):
  1. search.list  -> candidate video ids matching keyword/filters
  2. videos.list   -> statistics + contentDetails (view count, duration) for
                       those ids in a single batched call

Only the `fields` param is used to trim response payload size; no extra
caching layer here (SearchHistory caching happens at the API layer in
app.api.search so it also covers TikTok results).

Never hardcode YOUTUBE_API_KEY; always read from app.core.config.
"""
import re

import httpx

from app.core.config import get_settings

settings = get_settings()

_SEARCH_URL = "https://www.googleapis.com/youtube/v3/search"
_VIDEOS_URL = "https://www.googleapis.com/youtube/v3/videos"
_TIMEOUT = httpx.Timeout(15.0, connect=10.0)

_SEARCH_FIELDS = "items(id/videoId,snippet(title,channelTitle,publishedAt,thumbnails/high/url))"
_VIDEOS_FIELDS = "items(id,statistics/viewCount,contentDetails/duration,snippet/tags)"


class YouTubeAPIError(Exception):
    pass


def _parse_iso8601_duration(duration: str) -> int | None:
    """Convert 'PT1H2M3S' style ISO 8601 durations to whole seconds."""
    if not duration:
        return None
    match = re.match(r"^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$", duration)
    if not match:
        return None
    hours, minutes, seconds = (int(x) if x else 0 for x in match.groups())
    return hours * 3600 + minutes * 60 + seconds


async def _fetch_video_stats(client: httpx.AsyncClient, video_ids: list[str]) -> dict[str, dict]:
    if not video_ids:
        return {}

    resp = await client.get(
        _VIDEOS_URL,
        params={
            "part": "statistics,contentDetails,snippet",
            "id": ",".join(video_ids),
            "fields": _VIDEOS_FIELDS,
            "key": settings.YOUTUBE_API_KEY,
        },
    )
    resp.raise_for_status()
    items = resp.json().get("items", [])

    stats: dict[str, dict] = {}
    for item in items:
        video_id = item["id"]
        statistics = item.get("statistics", {})
        content_details = item.get("contentDetails", {})
        snippet = item.get("snippet", {})
        stats[video_id] = {
            "views": int(statistics["viewCount"]) if statistics.get("viewCount") else None,
            "duration": _parse_iso8601_duration(content_details.get("duration", "")),
            "tags": snippet.get("tags") or [],
        }
    return stats


async def search_youtube(
    keyword: str,
    *,
    max_results: int = 25,
    order: str = "relevance",
    published_after: str | None = None,
    region_code: str | None = None,
    video_duration: str | None = None,
    relevance_language: str | None = None,
) -> list[dict]:
    """
    Search YouTube for videos matching `keyword` + optional filters, and
    return normalized dicts ready to build app.models.video.Video rows.

    Raises YouTubeAPIError if YOUTUBE_API_KEY is unset or the API errors.
    """
    if not settings.YOUTUBE_API_KEY:
        raise YouTubeAPIError("YOUTUBE_API_KEY not configured")

    params = {
        "part": "snippet",
        "q": keyword,
        "type": "video",
        "maxResults": min(max_results, 50),
        "order": order,
        "fields": _SEARCH_FIELDS,
        "key": settings.YOUTUBE_API_KEY,
    }
    if published_after:
        params["publishedAfter"] = published_after
    if region_code:
        params["regionCode"] = region_code
    if video_duration:
        params["videoDuration"] = video_duration
    if relevance_language:
        params["relevanceLanguage"] = relevance_language

    async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
        try:
            resp = await client.get(_SEARCH_URL, params=params)
            resp.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise YouTubeAPIError(f"search.list failed: HTTP {exc.response.status_code}") from exc
        except httpx.TransportError as exc:
            raise YouTubeAPIError(f"search.list network error: {exc}") from exc

        items = resp.json().get("items", [])
        video_ids = [item["id"]["videoId"] for item in items if item.get("id", {}).get("videoId")]

        try:
            stats_by_id = await _fetch_video_stats(client, video_ids)
        except httpx.HTTPStatusError as exc:
            raise YouTubeAPIError(f"videos.list failed: HTTP {exc.response.status_code}") from exc

    results = []
    for item in items:
        video_id = item.get("id", {}).get("videoId")
        if not video_id:
            continue
        snippet = item.get("snippet", {})
        stats = stats_by_id.get(video_id, {})
        results.append({
            "platform": "youtube",
            "title": snippet.get("title", ""),
            "channel": snippet.get("channelTitle"),
            "url": f"https://www.youtube.com/watch?v={video_id}",
            "publish_date": snippet.get("publishedAt"),
            "views": stats.get("views"),
            "duration": stats.get("duration"),
            "thumbnail": (snippet.get("thumbnails", {}).get("high") or {}).get("url"),
            "tags": ",".join(stats.get("tags", [])) if stats.get("tags") else None,
        })
    return results
