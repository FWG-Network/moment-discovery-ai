"""
SEO Viral Agent.

Generates only: Viral Titles, SEO Keywords, Trending Keywords, Hashtags,
Related Search Queries, targeting the US market. No descriptions, no
scripts (AI_Rules: short, structured output only).
"""
from app.ai.router import generate, extract_json, AIProviderError
from app.schemas.agent_outputs import SeoViralResult

_PROMPT_TEMPLATE = """\
Generate a viral SEO package for a ranking-style YouTube/TikTok video about: \
"{topic}"

Target audience: US market. Use current, natural internet slang where it \
fits (not forced).

Return ONLY a JSON object (no prose, no markdown fences) with exactly these \
fields:
- viral_titles: array of 5 short punchy title options
- seo_keywords: array of 5-8 keywords
- trending_keywords: array of 3-5 currently-relevant keywords
- hashtags: array of 5-8 hashtags (include the # symbol)
- related_search_queries: array of 3-5 queries people might search"""


class SeoViralAgentError(Exception):
    pass


async def generate_seo_package(topic: str) -> SeoViralResult:
    prompt = _PROMPT_TEMPLATE.format(topic=topic)

    try:
        raw = await generate(prompt, json_mode=True)
        return SeoViralResult.model_validate(extract_json(raw))
    except (AIProviderError, ValueError) as exc:
        raise SeoViralAgentError(str(exc)) from exc
