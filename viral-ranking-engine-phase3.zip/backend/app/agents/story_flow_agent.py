"""
Story Flow Agent.

Suggests the best ranking order for a set of moments, following a
"Conflict -> Escalation -> Turning Point" arc (weakest/mildest first,
building to the most shocking/funny at #1). Returns ordering only — no
scripts, no descriptions (AI_Rules: short, structured output).
"""
from app.ai.router import generate, extract_json, AIProviderError
from app.schemas.agent_outputs import StoryFlowResult

_PROMPT_TEMPLATE = """\
You are ordering video moments into a ranking-style countdown video, using \
a "Conflict -> Escalation -> Turning Point" arc: start milder/lower-impact \
and escalate to the most shocking/funny moment saved for #1.

Moments (id: description):
{moments_list}

Return ONLY a JSON object (no prose, no markdown fences) with exactly this \
field:
- ranked_moment_ids: array of the moment ids above, ordered from lowest \
impact (countdown start, e.g. #10) to highest impact (#1, last revealed)"""


class StoryFlowAgentError(Exception):
    pass


async def order_moments(moments: list[dict]) -> StoryFlowResult:
    """moments: list of {"id": int, "description": str}."""
    moments_list = "\n".join(f"- {m['id']}: {m.get('description') or '(no description)'}" for m in moments)

    prompt = _PROMPT_TEMPLATE.format(moments_list=moments_list or "(none provided)")

    try:
        raw = await generate(prompt, json_mode=True)
        result = StoryFlowResult.model_validate(extract_json(raw))
    except (AIProviderError, ValueError) as exc:
        raise StoryFlowAgentError(str(exc)) from exc

    # Guard against the model inventing/dropping ids: fall back to input order
    # for anything it didn't return, rather than silently losing moments.
    valid_ids = {m["id"] for m in moments}
    returned = [mid for mid in result.ranked_moment_ids if mid in valid_ids]
    missing = [m["id"] for m in moments if m["id"] not in returned]
    result.ranked_moment_ids = returned + missing
    return result
