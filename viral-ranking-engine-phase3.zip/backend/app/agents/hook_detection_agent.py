"""
Hook Detection Agent.

Estimates how strongly a video's opening hooks a scroller/viewer in the
first few seconds, based on title/thumbnail/tags text signals (we don't
have frame-level video access). Returns only: Scroll Stop Score, Hook
Strength, Curiosity Level — no long explanations (AI_Rules).
"""
from app.ai.router import generate, extract_json, AIProviderError
from app.schemas.agent_outputs import HookDetectionResult

_PROMPT_TEMPLATE = """\
Estimate how strongly this video's title/thumbnail would hook a viewer \
scrolling past it in the first 2-3 seconds.

Title: {title}
Thumbnail description/tags: {tags}
Platform: {platform}

Return ONLY a JSON object (no prose, no markdown fences) with exactly these \
fields:
- scroll_stop_score: float 0-100
- hook_strength: float 0-100
- curiosity_level: float 0-100"""


class HookDetectionAgentError(Exception):
    pass


async def detect_hook(video_metadata: dict) -> HookDetectionResult:
    """video_metadata expects keys: title, tags, platform (all optional)."""
    prompt = _PROMPT_TEMPLATE.format(
        title=video_metadata.get("title", ""),
        tags=video_metadata.get("tags") or "none",
        platform=video_metadata.get("platform", ""),
    )

    try:
        raw = await generate(prompt, json_mode=True, model_hint=None)
        return HookDetectionResult.model_validate(extract_json(raw))
    except (AIProviderError, ValueError) as exc:
        raise HookDetectionAgentError(str(exc)) from exc
