"""
Competitor Research Agent.

Analyzes a competitor channel's recent videos and returns concise insights
only: popular topics, upload frequency, title patterns, thumbnail patterns,
opportunities. Takes already-fetched video metadata (from app.models.video
rows or a fresh app.services.youtube_service.search_youtube call scoped to
the channel) rather than fetching anything itself, keeping this module a
pure analysis step.
"""
from app.ai.router import generate, extract_json, AIProviderError
from app.schemas.agent_outputs import CompetitorInsight

_PROMPT_TEMPLATE = """\
Analyze this competitor channel's recent videos and summarize patterns a \
ranking-video creator could learn from or find a gap in.

Channel: {channel}

Recent videos (title | views | published):
{videos_list}

Return ONLY a JSON object (no prose, no markdown fences) with exactly these \
fields:
- popular_topics: array of 3-5 recurring topics
- upload_frequency: short string, e.g. "roughly daily" or "2-3x per week"
- title_patterns: array of 2-4 recurring title patterns/phrasing
- thumbnail_patterns: array of 2-4 likely thumbnail patterns inferred from titles/topics
- opportunities: array of 2-4 content gaps or angles this channel is NOT covering"""


class CompetitorResearchAgentError(Exception):
    pass


async def analyze_competitor(channel: str, recent_videos: list[dict]) -> CompetitorInsight:
    """recent_videos: list of {"title": str, "views": int|None, "publish_date": str|None}."""
    videos_list = "\n".join(
        f"- {v.get('title', '')} | {v.get('views', 'unknown')} views | {v.get('publish_date', 'unknown')}"
        for v in recent_videos
    )

    prompt = _PROMPT_TEMPLATE.format(channel=channel, videos_list=videos_list or "(no videos available)")

    try:
        raw = await generate(prompt, json_mode=True)
        return CompetitorInsight.model_validate(extract_json(raw))
    except (AIProviderError, ValueError) as exc:
        raise CompetitorResearchAgentError(str(exc)) from exc
