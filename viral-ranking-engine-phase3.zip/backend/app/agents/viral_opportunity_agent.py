"""
Viral Opportunity Agent.

Scores a video's overall viral potential. Prioritizes outlier detection
(views relative to what's typical for a channel of similar size, using
duration/recency as rough proxies since we don't track subscriber counts)
over absolute view counts, and favors recency (7-30 day window) to surface
emerging trends over already-saturated viral hits.

Uses app.ai.router.generate() only, with json_mode=True to constrain output
to the ViralOpportunityResult contract.
"""
from app.ai.router import generate, extract_json, AIProviderError
from app.schemas.agent_outputs import ViralOpportunityResult

_PROMPT_TEMPLATE = """\
You are scoring a video's potential to become a viral "ranking video" \
opportunity (funny fails, epic fails, instant karma, lucky escapes, sports \
fails, animal fails, unexpected/funny moments).

Video metadata:
- Title: {title}
- Platform: {platform}
- Channel: {channel}
- Views: {views}
- Duration (seconds): {duration}
- Published: {publish_date}
- Tags: {tags}

Score outlier potential (is this unusually high-performing for its channel \
size/recency, not just high absolute views) and recency (favor 7-30 day \
old content surfacing an emerging trend over old saturated hits).

Return ONLY a JSON object (no prose, no markdown fences) with exactly these \
fields:
- viral_score: float 0-100
- engagement_ratio: float 0-10 (rough views-vs-norm heuristic; 1.0 = typical, higher = outlier)
- hook_score: float 0-100
- curiosity_score: float 0-100
- replay_potential: float 0-100
- freshness: float 0-100 (higher = more recent/emerging)
- overall_recommendation: short string, one sentence max"""


class ViralOpportunityAgentError(Exception):
    pass


async def score_video(video_metadata: dict) -> ViralOpportunityResult:
    """
    video_metadata expects keys: title, platform, channel, views, duration,
    publish_date, tags (all optional except title/platform).
    """
    prompt = _PROMPT_TEMPLATE.format(
        title=video_metadata.get("title", ""),
        platform=video_metadata.get("platform", ""),
        channel=video_metadata.get("channel") or "unknown",
        views=video_metadata.get("views") if video_metadata.get("views") is not None else "unknown",
        duration=video_metadata.get("duration") if video_metadata.get("duration") is not None else "unknown",
        publish_date=video_metadata.get("publish_date") or "unknown",
        tags=video_metadata.get("tags") or "none",
    )

    try:
        raw = await generate(prompt, json_mode=True)
        return ViralOpportunityResult.model_validate(extract_json(raw))
    except (AIProviderError, ValueError) as exc:
        raise ViralOpportunityAgentError(str(exc)) from exc
