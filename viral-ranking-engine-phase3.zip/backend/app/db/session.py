"""
Database session management.

SQLite has no true async driver support for SQLAlchemy's ORM layer, so we use
a synchronous engine and wrap calls in `run_in_threadpool` at the API layer
(see app/api). This keeps the FastAPI event loop unblocked without adding
extra infra (no Redis, no Celery, no async DB driver).
"""
from collections.abc import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session

from app.core.config import get_settings

settings = get_settings()

engine = create_engine(
    settings.DATABASE_URL,
    connect_args={"check_same_thread": False},
    pool_pre_ping=True,
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db() -> Generator[Session, None, None]:
    """FastAPI dependency that yields a DB session and closes it afterward."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
