"""
Search result caching.

Checked before any YouTube/TikTok/LLM call to avoid duplicate external
requests for the same query within the TTL window (AI_Rules: minimize token
usage; also saves YouTube quota).
"""
import json
from datetime import datetime, timedelta, timezone

from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.models.search_history import SearchHistory

settings = get_settings()


def get_cached_results(db: Session, query: str, platform: str) -> list[dict] | None:
    """Return cached results if a matching, non-expired entry exists."""
    entry = (
        db.query(SearchHistory)
        .filter(
            SearchHistory.query == query,
            SearchHistory.platform == platform,
            SearchHistory.ttl_expires > datetime.now(timezone.utc).replace(tzinfo=None),
        )
        .order_by(SearchHistory.created_at.desc())
        .first()
    )
    if entry is None or entry.cached_result is None:
        return None
    return json.loads(entry.cached_result)


def save_cached_results(db: Session, query: str, platform: str, results: list[dict]) -> None:
    entry = SearchHistory(
        query=query,
        platform=platform,
        cached_result=json.dumps(results, default=str),
        ttl_expires=datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(days=settings.SEARCH_CACHE_TTL_DAYS),
    )
    db.add(entry)
    db.commit()
