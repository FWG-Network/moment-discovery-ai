"""
Unified AI router.

Per AI_Rules: only `generate()` is exposed. Do not add summarize(), rewrite(),
classify(), rank(), or reason() functions — agents express everything as a
single prompt into generate() and parse structured JSON back out.

Provider failover order:
  1. GitHub Models   (GITHUB_MODELS_TOKEN, MODEL_REASONING/MODEL_WRITER)
  2. OpenRouter       (OPENROUTER_API_KEY, OPENROUTER_MODEL)
  3. AGENT_URL        (custom fallback endpoint)

Each provider is tried in order; if one is unconfigured (missing key) or
fails (HTTP error, timeout), the next is attempted. All failures are
collected and raised together only if every provider fails.
"""
import json
import re

import httpx

from app.core.config import get_settings

settings = get_settings()

_TIMEOUT = httpx.Timeout(30.0, connect=10.0)
_MAX_RETRIES = 2  # per-provider retry count for transient errors


class AIProviderError(Exception):
    """Raised when a provider is unconfigured or fails after retries."""


async def _post_with_retry(url: str, *, headers: dict, json_body: dict) -> dict:
    last_exc: Exception | None = None
    async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
        for _attempt in range(_MAX_RETRIES + 1):
            try:
                resp = await client.post(url, headers=headers, json=json_body)
                resp.raise_for_status()
                return resp.json()
            except (httpx.TimeoutException, httpx.TransportError) as exc:
                last_exc = exc
                continue
            except httpx.HTTPStatusError as exc:
                # Retry on rate limit / server errors, fail fast on 4xx (bad request/auth)
                if exc.response.status_code in (429, 500, 502, 503, 504):
                    last_exc = exc
                    continue
                raise AIProviderError(f"HTTP {exc.response.status_code}: {exc.response.text[:200]}") from exc
    raise AIProviderError(f"Exhausted retries: {last_exc}")


async def _call_github_models(prompt: str, model_hint: str | None, json_mode: bool) -> str:
    if not settings.GITHUB_MODELS_TOKEN:
        raise AIProviderError("GITHUB_MODELS_TOKEN not configured")

    model = model_hint or settings.MODEL_REASONING or "gpt-4o-mini"
    body = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.3,
    }
    if json_mode:
        body["response_format"] = {"type": "json_object"}

    data = await _post_with_retry(
        "https://models.inference.ai.azure.com/chat/completions",
        headers={
            "Authorization": f"Bearer {settings.GITHUB_MODELS_TOKEN}",
            "Content-Type": "application/json",
        },
        json_body=body,
    )
    return data["choices"][0]["message"]["content"]


async def _call_openrouter(prompt: str, model_hint: str | None, json_mode: bool) -> str:
    if not settings.OPENROUTER_API_KEY:
        raise AIProviderError("OPENROUTER_API_KEY not configured")

    model = model_hint or settings.OPENROUTER_MODEL or "openai/gpt-4o-mini"
    body = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
    }
    if json_mode:
        body["response_format"] = {"type": "json_object"}

    data = await _post_with_retry(
        "https://openrouter.ai/api/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {settings.OPENROUTER_API_KEY}",
            "Content-Type": "application/json",
        },
        json_body=body,
    )
    return data["choices"][0]["message"]["content"]


async def _call_agent_url(prompt: str, model_hint: str | None, json_mode: bool = False) -> str:
    if not settings.AGENT_URL:
        raise AIProviderError("AGENT_URL not configured")

    data = await _post_with_retry(
        settings.AGENT_URL,
        headers={"Content-Type": "application/json"},
        json_body={"prompt": prompt, "model": model_hint, "json_mode": json_mode},
    )
    # Custom endpoint contract: {"text": "..."} or {"content": "..."}
    text = data.get("text") or data.get("content")
    if text is None:
        raise AIProviderError("AGENT_URL response missing 'text'/'content' field")
    return text


_PROVIDERS = (
    ("github_models", _call_github_models),
    ("openrouter", _call_openrouter),
    ("agent_url", _call_agent_url),
)


async def generate(prompt: str, *, model_hint: str | None = None, json_mode: bool = False) -> str:
    """
    Send `prompt` to the first configured, working provider and return the
    raw text response.

    If json_mode=True, OpenAI-compatible providers (GitHub Models,
    OpenRouter) are asked to constrain their output to valid JSON via
    response_format. This does not guarantee well-formed JSON on every
    provider (AGENT_URL's contract is custom) — always parse the result with
    extract_json() rather than assuming it succeeded.
    """
    errors: dict[str, str] = {}
    for name, fn in _PROVIDERS:
        try:
            return await fn(prompt, model_hint, json_mode)
        except AIProviderError as exc:
            errors[name] = str(exc)

    raise AIProviderError(f"All AI providers failed or are unconfigured: {errors}")


async def generate_via_browsing_agent(prompt: str, *, model_hint: str | None = None) -> str:
    """
    Like generate(), but restricted to AGENT_URL only.

    Plain chat-completion providers (GitHub Models, OpenRouter) cannot browse
    the live web — asking them to "search TikTok" would just hallucinate
    plausible-looking but fake URLs and stats. Use this entrypoint for any
    task that genuinely needs current, real web results (e.g. TikTok
    discovery); AGENT_URL is expected to point at an agent/endpoint with
    real search or browsing capability.
    """
    try:
        return await _call_agent_url(prompt, model_hint, json_mode=True)
    except AIProviderError as exc:
        raise AIProviderError(
            "No browsing-capable provider configured. Set AGENT_URL to an "
            f"endpoint with real web-search capability. ({exc})"
        ) from exc


def extract_json(text: str):
    """
    Parse a JSON object/array out of a model response, tolerating common
    formatting noise (markdown code fences, leading/trailing prose).
    """
    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass

    # Fall back to locating the first {...} or [...] block.
    match = re.search(r"(\{.*\}|\[.*\])", cleaned, re.DOTALL)
    if match:
        return json.loads(match.group(1))
    raise ValueError(f"Could not extract JSON from model response: {text[:200]!r}")
