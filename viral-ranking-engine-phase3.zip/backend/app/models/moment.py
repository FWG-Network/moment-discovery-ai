from datetime import datetime

from sqlalchemy import String, Integer, Float, DateTime, ForeignKey, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


class Moment(Base):
    """A specific viral moment identified inside a video, with a viral score."""

    __tablename__ = "moments"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    video_id: Mapped[int] = mapped_column(ForeignKey("videos.id"), index=True)
    timestamp: Mapped[int | None] = mapped_column(Integer, nullable=True)  # seconds into video
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    viral_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
