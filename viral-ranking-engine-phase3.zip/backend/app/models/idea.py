from datetime import datetime

from sqlalchemy import Integer, Float, DateTime, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


class Idea(Base):
    """A ranked idea (moment placed into a ranking-video slot)."""

    __tablename__ = "ideas"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    moment_id: Mapped[int] = mapped_column(ForeignKey("moments.id"), index=True)
    rank_position: Mapped[int | None] = mapped_column(Integer, nullable=True)  # e.g. 10 -> 1
    hook_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    curiosity_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
