from datetime import datetime

from sqlalchemy import String, DateTime, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


class SearchHistory(Base):
    """Cache of prior search results, keyed by query+filters, with a TTL.

    Checked before any LLM/agent invocation to avoid duplicate AI requests
    (see AI_Rules: minimize token usage).
    """

    __tablename__ = "search_history"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    query: Mapped[str] = mapped_column(String(255), index=True)
    platform: Mapped[str] = mapped_column(String(20))
    filters: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON string
    cached_result: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON string
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    ttl_expires: Mapped[datetime] = mapped_column(DateTime)
