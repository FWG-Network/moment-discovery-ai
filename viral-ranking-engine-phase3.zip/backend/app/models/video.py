from datetime import datetime

from sqlalchemy import String, Integer, Float, DateTime, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


class Video(Base):
    """A discovered video (YouTube or TikTok) with public metadata only."""

    __tablename__ = "videos"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    platform: Mapped[str] = mapped_column(String(20), index=True)  # "youtube" | "tiktok"
    title: Mapped[str] = mapped_column(String(500))
    channel: Mapped[str] = mapped_column(String(255), nullable=True)
    url: Mapped[str] = mapped_column(String(1000), unique=True)
    publish_date: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    views: Mapped[int | None] = mapped_column(Integer, nullable=True)
    duration: Mapped[int | None] = mapped_column(Integer, nullable=True)  # seconds
    thumbnail: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    tags: Mapped[str | None] = mapped_column(Text, nullable=True)  # comma-separated

    # Set by Viral Opportunity Agent (Phase 3). viral_score is the overall
    # opportunity score for the whole video; engagement_ratio is a rough
    # views-vs-norm heuristic since we don't track subscriber counts.
    # Moment.viral_score (separate table) scores individual clips within it.
    viral_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    engagement_ratio: Mapped[float | None] = mapped_column(Float, nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

