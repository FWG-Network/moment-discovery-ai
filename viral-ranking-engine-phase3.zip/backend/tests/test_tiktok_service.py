import pytest

from app.services import tiktok_service


async def test_search_tiktok_raises_without_agent_url(monkeypatch):
    monkeypatch.setattr(tiktok_service, "generate_via_browsing_agent", _raise_unconfigured)
    with pytest.raises(tiktok_service.TikTokDiscoveryError):
        await tiktok_service.search_tiktok("epic fail")


async def _raise_unconfigured(*args, **kwargs):
    from app.ai.router import AIProviderError
    raise AIProviderError("AGENT_URL not configured")


async def test_search_tiktok_parses_valid_json_array(monkeypatch):
    async def _fake_generate(*args, **kwargs):
        return (
            '[{"title": "Guy trips over dog", "url": "https://tiktok.com/@user/video/123", '
            '"creator": "@user", "thumbnail": null, "search_source": "site:tiktok.com fail"}]'
        )

    monkeypatch.setattr(tiktok_service, "generate_via_browsing_agent", _fake_generate)
    results = await tiktok_service.search_tiktok("fail")

    assert len(results) == 1
    item = results[0]
    assert item["platform"] == "tiktok"
    assert item["title"] == "Guy trips over dog"
    assert item["url"] == "https://tiktok.com/@user/video/123"
    assert item["channel"] == "@user"


async def test_search_tiktok_skips_malformed_items_without_failing_batch(monkeypatch):
    async def _fake_generate(*args, **kwargs):
        return (
            "["
            '{"title": "Valid item", "url": "https://tiktok.com/@a/video/1"},'
            '{"url_missing_title": true}'
            "]"
        )

    monkeypatch.setattr(tiktok_service, "generate_via_browsing_agent", _fake_generate)
    results = await tiktok_service.search_tiktok("fail")

    assert len(results) == 1
    assert results[0]["title"] == "Valid item"


async def test_search_tiktok_raises_on_non_json_response(monkeypatch):
    async def _fake_generate(*args, **kwargs):
        return "Sorry, I can't help with that."

    monkeypatch.setattr(tiktok_service, "generate_via_browsing_agent", _fake_generate)
    with pytest.raises(tiktok_service.TikTokDiscoveryError):
        await tiktok_service.search_tiktok("fail")


async def test_search_tiktok_raises_when_response_is_not_a_list(monkeypatch):
    async def _fake_generate(*args, **kwargs):
        return '{"not": "a list"}'

    monkeypatch.setattr(tiktok_service, "generate_via_browsing_agent", _fake_generate)
    with pytest.raises(tiktok_service.TikTokDiscoveryError):
        await tiktok_service.search_tiktok("fail")
