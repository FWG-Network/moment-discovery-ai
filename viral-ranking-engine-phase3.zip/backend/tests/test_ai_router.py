import httpx
import pytest
import respx

from app.ai import router as ai_router


@pytest.fixture(autouse=True)
def _configure_settings(monkeypatch):
    """Give every provider a fake key/url so failover logic actually runs."""
    monkeypatch.setattr(ai_router.settings, "GITHUB_MODELS_TOKEN", "fake-github-token")
    monkeypatch.setattr(ai_router.settings, "OPENROUTER_API_KEY", "fake-openrouter-key")
    monkeypatch.setattr(ai_router.settings, "AGENT_URL", "https://agent.example.com/generate")
    yield


@respx.mock
async def test_generate_uses_first_provider_when_it_succeeds():
    respx.post("https://models.inference.ai.azure.com/chat/completions").mock(
        return_value=httpx.Response(200, json={"choices": [{"message": {"content": "hello from github"}}]})
    )
    result = await ai_router.generate("test prompt")
    assert result == "hello from github"


@respx.mock
async def test_generate_fails_over_to_openrouter_when_github_errors():
    respx.post("https://models.inference.ai.azure.com/chat/completions").mock(
        return_value=httpx.Response(401, json={"error": "bad auth"})
    )
    respx.post("https://openrouter.ai/api/v1/chat/completions").mock(
        return_value=httpx.Response(200, json={"choices": [{"message": {"content": "hello from openrouter"}}]})
    )
    result = await ai_router.generate("test prompt")
    assert result == "hello from openrouter"


@respx.mock
async def test_generate_fails_over_all_the_way_to_agent_url():
    respx.post("https://models.inference.ai.azure.com/chat/completions").mock(
        return_value=httpx.Response(500)
    )
    respx.post("https://openrouter.ai/api/v1/chat/completions").mock(
        return_value=httpx.Response(500)
    )
    respx.post("https://agent.example.com/generate").mock(
        return_value=httpx.Response(200, json={"text": "hello from agent"})
    )
    result = await ai_router.generate("test prompt")
    assert result == "hello from agent"


@respx.mock
async def test_generate_raises_when_all_providers_fail():
    respx.post("https://models.inference.ai.azure.com/chat/completions").mock(
        return_value=httpx.Response(500)
    )
    respx.post("https://openrouter.ai/api/v1/chat/completions").mock(
        return_value=httpx.Response(500)
    )
    respx.post("https://agent.example.com/generate").mock(
        return_value=httpx.Response(500)
    )
    with pytest.raises(ai_router.AIProviderError):
        await ai_router.generate("test prompt")


def test_extract_json_handles_markdown_fences():
    text = '```json\n{"a": 1}\n```'
    assert ai_router.extract_json(text) == {"a": 1}


def test_extract_json_handles_plain_json():
    assert ai_router.extract_json('{"a": 1}') == {"a": 1}


def test_extract_json_handles_surrounding_prose():
    text = 'Sure, here is the result:\n[{"a": 1}]\nHope that helps!'
    assert ai_router.extract_json(text) == [{"a": 1}]


def test_extract_json_raises_on_garbage():
    with pytest.raises(ValueError):
        ai_router.extract_json("not json at all")
