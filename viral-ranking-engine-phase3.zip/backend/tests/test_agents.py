import pytest

from app.agents import (
    viral_opportunity_agent,
    hook_detection_agent,
    story_flow_agent,
    seo_viral_agent,
    competitor_research_agent,
)


# --- Viral Opportunity Agent ---

async def test_score_video_returns_validated_result(monkeypatch):
    async def _fake_generate(*args, **kwargs):
        return (
            '{"viral_score": 88.5, "engagement_ratio": 3.2, "hook_score": 70, '
            '"curiosity_score": 65, "replay_potential": 50, "freshness": 90, '
            '"overall_recommendation": "Strong outlier, act fast."}'
        )

    monkeypatch.setattr(viral_opportunity_agent, "generate", _fake_generate)
    result = await viral_opportunity_agent.score_video({"title": "Guy trips", "platform": "youtube"})

    assert result.viral_score == 88.5
    assert result.engagement_ratio == 3.2


async def test_score_video_raises_on_provider_failure(monkeypatch):
    async def _fake_generate(*args, **kwargs):
        from app.ai.router import AIProviderError
        raise AIProviderError("all providers down")

    monkeypatch.setattr(viral_opportunity_agent, "generate", _fake_generate)
    with pytest.raises(viral_opportunity_agent.ViralOpportunityAgentError):
        await viral_opportunity_agent.score_video({"title": "x", "platform": "youtube"})


async def test_score_video_raises_on_invalid_schema(monkeypatch):
    async def _fake_generate(*args, **kwargs):
        return '{"missing": "required fields"}'

    monkeypatch.setattr(viral_opportunity_agent, "generate", _fake_generate)
    with pytest.raises(viral_opportunity_agent.ViralOpportunityAgentError):
        await viral_opportunity_agent.score_video({"title": "x", "platform": "youtube"})


# --- Hook Detection Agent ---

async def test_detect_hook_returns_validated_result(monkeypatch):
    async def _fake_generate(*args, **kwargs):
        return '{"scroll_stop_score": 80, "hook_strength": 75, "curiosity_level": 60}'

    monkeypatch.setattr(hook_detection_agent, "generate", _fake_generate)
    result = await hook_detection_agent.detect_hook({"title": "You won't believe this fail"})
    assert result.scroll_stop_score == 80


# --- Story Flow Agent ---

async def test_order_moments_returns_validated_order(monkeypatch):
    async def _fake_generate(*args, **kwargs):
        return '{"ranked_moment_ids": [3, 1, 2]}'

    monkeypatch.setattr(story_flow_agent, "generate", _fake_generate)
    result = await story_flow_agent.order_moments([
        {"id": 1, "description": "mild fail"},
        {"id": 2, "description": "medium fail"},
        {"id": 3, "description": "huge fail"},
    ])
    assert result.ranked_moment_ids == [3, 1, 2]


async def test_order_moments_appends_missing_ids_the_model_dropped(monkeypatch):
    async def _fake_generate(*args, **kwargs):
        return '{"ranked_moment_ids": [2]}'  # model forgot id 1 and 3

    monkeypatch.setattr(story_flow_agent, "generate", _fake_generate)
    result = await story_flow_agent.order_moments([
        {"id": 1, "description": "a"},
        {"id": 2, "description": "b"},
        {"id": 3, "description": "c"},
    ])
    assert set(result.ranked_moment_ids) == {1, 2, 3}
    assert result.ranked_moment_ids[0] == 2  # model's ordering preserved first


async def test_order_moments_ignores_hallucinated_ids(monkeypatch):
    async def _fake_generate(*args, **kwargs):
        return '{"ranked_moment_ids": [1, 999, 2]}'  # 999 doesn't exist

    monkeypatch.setattr(story_flow_agent, "generate", _fake_generate)
    result = await story_flow_agent.order_moments([
        {"id": 1, "description": "a"},
        {"id": 2, "description": "b"},
    ])
    assert result.ranked_moment_ids == [1, 2]


# --- SEO Viral Agent ---

async def test_generate_seo_package_returns_validated_result(monkeypatch):
    async def _fake_generate(*args, **kwargs):
        return (
            '{"viral_titles": ["Title 1"], "seo_keywords": ["kw1"], '
            '"trending_keywords": ["trend1"], "hashtags": ["#fail"], '
            '"related_search_queries": ["funny fails"]}'
        )

    monkeypatch.setattr(seo_viral_agent, "generate", _fake_generate)
    result = await seo_viral_agent.generate_seo_package("epic fails compilation")
    assert result.viral_titles == ["Title 1"]


# --- Competitor Research Agent ---

async def test_analyze_competitor_returns_validated_result(monkeypatch):
    async def _fake_generate(*args, **kwargs):
        return (
            '{"popular_topics": ["fails"], "upload_frequency": "daily", '
            '"title_patterns": ["ALL CAPS"], "thumbnail_patterns": ["red arrows"], '
            '"opportunities": ["animal fails gap"]}'
        )

    monkeypatch.setattr(competitor_research_agent, "generate", _fake_generate)
    result = await competitor_research_agent.analyze_competitor(
        "FailChannel", [{"title": "Fail #1", "views": 1000, "publish_date": "2026-07-01"}]
    )
    assert result.upload_frequency == "daily"
