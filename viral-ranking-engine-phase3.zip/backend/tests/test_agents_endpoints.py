import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.api import agents as agents_api


@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c


def _seed_video(client, url_suffix: str, channel: str = "TestChannel") -> int:
    from app.db.session import SessionLocal
    from app.models.video import Video

    db = SessionLocal()
    video = Video(
        platform="youtube",
        title="Test video",
        channel=channel,
        url=f"https://youtube.com/watch?v={url_suffix}",
        views=1000,
        duration=60,
    )
    db.add(video)
    db.commit()
    db.refresh(video)
    video_id = video.id
    db.close()
    return video_id


def _seed_moment(video_id: int, description: str) -> int:
    from app.db.session import SessionLocal
    from app.models.moment import Moment

    db = SessionLocal()
    moment = Moment(video_id=video_id, description=description, timestamp=10)
    db.add(moment)
    db.commit()
    db.refresh(moment)
    moment_id = moment.id
    db.close()
    return moment_id


def test_viral_opportunity_endpoint_persists_scores_to_video(client, monkeypatch):
    video_id = _seed_video(client, "viral-opp-test")

    async def _fake_score_video(metadata):
        from app.schemas.agent_outputs import ViralOpportunityResult
        return ViralOpportunityResult(
            viral_score=91.0, engagement_ratio=4.1, hook_score=80, curiosity_score=70,
            replay_potential=60, freshness=95, overall_recommendation="Great pickup.",
        )

    monkeypatch.setattr(agents_api, "score_video", _fake_score_video)

    resp = client.post(f"/agents/viral-opportunity?video_id={video_id}")
    assert resp.status_code == 200
    assert resp.json()["viral_score"] == 91.0

    video = client.get(f"/videos/{video_id}").json()
    assert video["viral_score"] == 91.0
    assert video["engagement_ratio"] == 4.1


def test_viral_opportunity_endpoint_404_for_missing_video(client):
    resp = client.post("/agents/viral-opportunity?video_id=999999")
    assert resp.status_code == 404


def test_story_flow_endpoint_orders_real_moments(client, monkeypatch):
    video_id = _seed_video(client, "story-flow-test")
    m1 = _seed_moment(video_id, "mild fail")
    m2 = _seed_moment(video_id, "huge fail")

    async def _fake_order_moments(moments):
        from app.schemas.agent_outputs import StoryFlowResult
        ids = [m["id"] for m in moments]
        return StoryFlowResult(ranked_moment_ids=list(reversed(ids)))

    monkeypatch.setattr(agents_api, "order_moments", _fake_order_moments)

    resp = client.post("/agents/story-flow", json=[m1, m2])
    assert resp.status_code == 200
    assert set(resp.json()["ranked_moment_ids"]) == {m1, m2}


def test_competitor_research_endpoint_404_when_no_videos_for_channel(client):
    resp = client.post("/agents/competitor-research?channel=NoSuchChannel")
    assert resp.status_code == 404


def test_competitor_research_endpoint_uses_seeded_videos(client, monkeypatch):
    _seed_video(client, "competitor-test", channel="RivalChannel")

    async def _fake_analyze(channel, videos):
        from app.schemas.agent_outputs import CompetitorInsight
        assert channel == "RivalChannel"
        assert len(videos) == 1
        return CompetitorInsight(
            popular_topics=["fails"], upload_frequency="daily",
            title_patterns=["caps"], thumbnail_patterns=["arrows"], opportunities=["gap"],
        )

    monkeypatch.setattr(agents_api, "analyze_competitor", _fake_analyze)

    resp = client.post("/agents/competitor-research?channel=RivalChannel")
    assert resp.status_code == 200
    assert resp.json()["upload_frequency"] == "daily"


def test_seo_viral_endpoint(client, monkeypatch):
    async def _fake_seo(topic):
        from app.schemas.agent_outputs import SeoViralResult
        return SeoViralResult(
            viral_titles=["T1"], seo_keywords=["k1"], trending_keywords=["t1"],
            hashtags=["#fail"], related_search_queries=["q1"],
        )

    monkeypatch.setattr(agents_api, "generate_seo_package", _fake_seo)

    resp = client.post("/agents/seo-viral?topic=epic+fails")
    assert resp.status_code == 200
    assert resp.json()["viral_titles"] == ["T1"]
