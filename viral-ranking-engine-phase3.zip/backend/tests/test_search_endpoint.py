import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.api import search as search_api


@pytest.fixture
def client():
    # app.main creates tables on startup against the configured DATABASE_URL
    # (sqlite:///./viral_ranking.db by default). The engine/connection pool
    # is created once at import time, so deleting the file mid-run breaks
    # later tests; instead each test uses a unique query string so shared
    # state across tests within a run is not an issue.
    with TestClient(app) as c:
        yield c


async def _fake_search_youtube(query, **kwargs):
    return [{
        "platform": "youtube",
        "title": f"YT result for {query}",
        "channel": "TestChannel",
        "url": f"https://youtube.com/watch?v={query.replace(' ', '_')}",
        "publish_date": "2026-07-01T00:00:00Z",
        "views": 1000,
        "duration": 60,
        "thumbnail": None,
        "tags": "test",
    }]


async def _fake_search_tiktok(query, **kwargs):
    return [{
        "platform": "tiktok",
        "title": f"TikTok result for {query}",
        "channel": "@testuser",
        "url": f"https://tiktok.com/@testuser/video/{query.replace(' ', '_')}",
        "publish_date": None,
        "views": None,
        "duration": None,
        "thumbnail": None,
        "tags": None,
    }]


def test_search_endpoint_persists_videos_from_both_platforms(client, monkeypatch):
    monkeypatch.setattr(search_api, "search_youtube", _fake_search_youtube)
    monkeypatch.setattr(search_api, "search_tiktok", _fake_search_tiktok)

    resp = client.post("/search/", json={"query": "unit test query"})
    assert resp.status_code == 200
    body = resp.json()
    assert body["query"] == "unit test query"
    assert body["results_count"] == 2

    videos = client.get("/videos/").json()
    urls = {v["url"] for v in videos}
    assert "https://youtube.com/watch?v=unit_test_query" in urls
    assert "https://tiktok.com/@testuser/video/unit_test_query" in urls


def test_search_endpoint_second_call_uses_cache_not_live_calls(client, monkeypatch):
    call_count = {"youtube": 0, "tiktok": 0}

    async def _counting_youtube(query, **kwargs):
        call_count["youtube"] += 1
        return await _fake_search_youtube(query, **kwargs)

    async def _counting_tiktok(query, **kwargs):
        call_count["tiktok"] += 1
        return await _fake_search_tiktok(query, **kwargs)

    monkeypatch.setattr(search_api, "search_youtube", _counting_youtube)
    monkeypatch.setattr(search_api, "search_tiktok", _counting_tiktok)

    client.post("/search/", json={"query": "cache test query"})
    client.post("/search/", json={"query": "cache test query"})

    assert call_count["youtube"] == 1  # second call should hit cache, not live service
    assert call_count["tiktok"] == 1


def test_search_endpoint_platform_filter_only_calls_one_service(client, monkeypatch):
    call_count = {"youtube": 0, "tiktok": 0}

    async def _counting_youtube(query, **kwargs):
        call_count["youtube"] += 1
        return await _fake_search_youtube(query, **kwargs)

    async def _counting_tiktok(query, **kwargs):
        call_count["tiktok"] += 1
        return await _fake_search_tiktok(query, **kwargs)

    monkeypatch.setattr(search_api, "search_youtube", _counting_youtube)
    monkeypatch.setattr(search_api, "search_tiktok", _counting_tiktok)

    client.post("/search/", json={"query": "yt only query", "filters": {"platform": "youtube"}})

    assert call_count["youtube"] == 1
    assert call_count["tiktok"] == 0
