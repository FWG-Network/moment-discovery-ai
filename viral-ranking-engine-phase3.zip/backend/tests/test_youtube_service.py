import httpx
import pytest
import respx

from app.services import youtube_service


@pytest.fixture(autouse=True)
def _configure_settings(monkeypatch):
    monkeypatch.setattr(youtube_service.settings, "YOUTUBE_API_KEY", "fake-yt-key")
    yield


def test_parse_iso8601_duration():
    assert youtube_service._parse_iso8601_duration("PT1H2M3S") == 3723
    assert youtube_service._parse_iso8601_duration("PT45S") == 45
    assert youtube_service._parse_iso8601_duration("PT5M") == 300
    assert youtube_service._parse_iso8601_duration("") is None
    assert youtube_service._parse_iso8601_duration("garbage") is None


@respx.mock
async def test_search_youtube_combines_search_and_stats():
    respx.get("https://www.googleapis.com/youtube/v3/search").mock(
        return_value=httpx.Response(200, json={
            "items": [
                {
                    "id": {"videoId": "abc123"},
                    "snippet": {
                        "title": "Epic Fail Compilation",
                        "channelTitle": "FailChannel",
                        "publishedAt": "2026-07-01T00:00:00Z",
                        "thumbnails": {"high": {"url": "https://img.example.com/abc123.jpg"}},
                    },
                }
            ]
        })
    )
    respx.get("https://www.googleapis.com/youtube/v3/videos").mock(
        return_value=httpx.Response(200, json={
            "items": [
                {
                    "id": "abc123",
                    "statistics": {"viewCount": "1500000"},
                    "contentDetails": {"duration": "PT2M30S"},
                    "snippet": {"tags": ["fail", "funny"]},
                }
            ]
        })
    )

    results = await youtube_service.search_youtube("epic fail")

    assert len(results) == 1
    video = results[0]
    assert video["platform"] == "youtube"
    assert video["title"] == "Epic Fail Compilation"
    assert video["channel"] == "FailChannel"
    assert video["url"] == "https://www.youtube.com/watch?v=abc123"
    assert video["views"] == 1500000
    assert video["duration"] == 150
    assert video["tags"] == "fail,funny"
    assert video["thumbnail"] == "https://img.example.com/abc123.jpg"


@respx.mock
async def test_search_youtube_returns_empty_when_no_results():
    respx.get("https://www.googleapis.com/youtube/v3/search").mock(
        return_value=httpx.Response(200, json={"items": []})
    )
    results = await youtube_service.search_youtube("a very obscure query with no hits")
    assert results == []


async def test_search_youtube_raises_without_api_key(monkeypatch):
    monkeypatch.setattr(youtube_service.settings, "YOUTUBE_API_KEY", None)
    with pytest.raises(youtube_service.YouTubeAPIError):
        await youtube_service.search_youtube("epic fail")


@respx.mock
async def test_search_youtube_raises_on_api_error():
    respx.get("https://www.googleapis.com/youtube/v3/search").mock(
        return_value=httpx.Response(403, json={"error": "quota exceeded"})
    )
    with pytest.raises(youtube_service.YouTubeAPIError):
        await youtube_service.search_youtube("epic fail")
