export default function Dashboard() {
  return (
    <div>
      <h1>Dashboard</h1>
      <p>Wired up in Phase 4.</p>
    </div>
  );
}
