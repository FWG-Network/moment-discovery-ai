export default function MomentSuggestions() {
  return (
    <div>
      <h1>MomentSuggestions</h1>
      <p>Wired up in Phase 4.</p>
    </div>
  );
}
