export default function SavedIdeas() {
  return (
    <div>
      <h1>SavedIdeas</h1>
      <p>Wired up in Phase 4.</p>
    </div>
  );
}
