export default function Trending() {
  return (
    <div>
      <h1>Trending</h1>
      <p>Wired up in Phase 4.</p>
    </div>
  );
}
