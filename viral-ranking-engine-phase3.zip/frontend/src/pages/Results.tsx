export default function Results() {
  return (
    <div>
      <h1>Results</h1>
      <p>Wired up in Phase 4.</p>
    </div>
  );
}
