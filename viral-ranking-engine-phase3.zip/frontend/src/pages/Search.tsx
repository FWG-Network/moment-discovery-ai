export default function Search() {
  return (
    <div>
      <h1>Search</h1>
      <p>Wired up in Phase 4.</p>
    </div>
  );
}
