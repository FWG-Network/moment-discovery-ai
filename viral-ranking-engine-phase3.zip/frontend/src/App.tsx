import { BrowserRouter, Routes, Route, Link } from "react-router-dom";

import Dashboard from "./pages/Dashboard";
import Search from "./pages/Search";
import Results from "./pages/Results";
import MomentSuggestions from "./pages/MomentSuggestions";
import Trending from "./pages/Trending";
import SavedIdeas from "./pages/SavedIdeas";

export default function App() {
  return (
    <BrowserRouter>
      <nav>
        <Link to="/">Dashboard</Link> | <Link to="/search">Search</Link> |{" "}
        <Link to="/results">Results</Link> |{" "}
        <Link to="/moments">Moment Suggestions</Link> |{" "}
        <Link to="/trending">Trending</Link> |{" "}
        <Link to="/saved">Saved Ideas</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/search" element={<Search />} />
        <Route path="/results" element={<Results />} />
        <Route path="/moments" element={<MomentSuggestions />} />
        <Route path="/trending" element={<Trending />} />
        <Route path="/saved" element={<SavedIdeas />} />
      </Routes>
    </BrowserRouter>
  );
}
